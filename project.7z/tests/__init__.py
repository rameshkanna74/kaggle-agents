"""Tests package initialization."""
